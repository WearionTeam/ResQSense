"""
Simple in-memory data source used to simulate a fire-station database.
"""

FIRE_STATIONS = [
    "Bombeiros Voluntarios de Aveiro",
    "Bombeiros Voluntarios de Agueda",
    "Bombeiros Voluntarios de Albergaria-a-Velha",
    "Bombeiros Voluntarios de Anadia",
    "Bombeiros Voluntarios de Coimbra",
    "Bombeiros Sapadores de Coimbra",
    "Bombeiros Voluntarios de Espinho",
    "Bombeiros Sapadores do Porto",
    "Bombeiros Voluntarios de Gaia",
    "Bombeiros Voluntarios de Matosinhos-Leixoes",
    "Bombeiros Sapadores de Braga",
    "Bombeiros Voluntarios de Guimaraes",
    "Bombeiros Voluntarios de Viseu",
    "Bombeiros Voluntarios de Leiria",
    "Bombeiros Voluntarios de Santarem",
    "Bombeiros Sapadores de Lisboa",
    "Bombeiros Voluntarios de Oeiras",
    "Bombeiros Voluntarios de Cascais",
    "Bombeiros Sapadores de Setubal",
    "Bombeiros Voluntarios de Faro",
]


def get_fire_station_names():
    """Return station names sorted alphabetically for UI suggestions."""
    return sorted(FIRE_STATIONS)

