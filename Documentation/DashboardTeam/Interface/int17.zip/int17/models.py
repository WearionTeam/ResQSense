

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

# --- CLASSES DE DADOS ---
# Classe 'BiometricData'
@dataclass
class BiometricData:
    heart_rate: int = 0
    oxygenation: int = 0  # SpO2
    temperature: float = 0.0
    processing_delay_sec: int = 0

# Classe 'Location' 
@dataclass
class Location:
    latitude: float = 0.0
    longitude: float = 0.0
    distance_relative: float = 0.0      # para o UWB, caso o GPS falhe     
    height: float = 0.0

# Classe 'Alert'
@dataclass
class Alert:
    operator_id: int       
    description: str       # descriçao do alerta 
    timestamp: datetime = field(default_factory=datetime.now)       # registrar automaticamente a hora exata

# --- CLASSES PRINCIPAIS ---

# Classe 'Operator' 

class Operator:
    def __init__(self, id: int, name: str, vest_id: str):
        self.id = id                
        self.name = name            
        self.vest_id = vest_id      
        
        self.biometrics = BiometricData()
        self.location = Location()
        
    def update_detail(self, new_data: dict):
        if 'hr' in new_data: self.biometrics.heart_rate = new_data['hr']     
        if 'spo2' in new_data: self.biometrics.oxygenation = new_data['spo2']
        if 'temp' in new_data: self.biometrics.temperature = new_data['temp']
        if 'lat' in new_data: self.location.latitude = new_data['lat']
        if 'long' in new_data: self.location.longitude = new_data['long']
        if 'height' in new_data: self.location.height = new_data['height']

    # --- ESTA É A FUNÇÃO QUE DEVE ESTAR A FALTAR ---
    def check_health_status(self):
        warnings = []
        is_critical = False

        if self.biometrics.heart_rate > 105: 
            warnings.append("HR HIGH")
            is_critical = True
        
        if self.biometrics.oxygenation < 95 and self.biometrics.oxygenation > 0: 
            warnings.append("SpO2 LOW")
            is_critical = True

        if self.biometrics.temperature > 37.8: 
            warnings.append("TEMP HIGH")
            is_critical = True

        return is_critical, warnings

# Classe 'Session'
class Session:                                  # quando o chefe inicia sessão cria uma nova sessao 
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.active_operators: List[Operator] = []              # vai guardar no max 6 objetos do tipo operador (max 6 operadores)
        self.alerts_log: List[Alert] = []                       

    def add_firefighter_to_team(self, operator: Operator):  # Adiciona um bombeiro à sessão atual 
        self.active_operators.append(operator)
        print(f"Operador {operator.name} ({operator.vest_id}) adicionado à missão.")

    def create_alert(self, alert: Alert):  #Regista um novo alerta na sessão 
        self.alerts_log.append(alert)
        print(f"ALERTA NOVO: {alert.description} para Operador ID {alert.operator_id}")

# Classe 'DashboardController' 
class DashboardController:          # onde vamos receber o "click" dos botões e diz oq fazer 
    def __init__(self):
        self.current_session: Optional[Session] = None
        self.logged_in_leader = None    #guardar quem é o Chefe de Equipa (Team Leader) que fez login

    def start_new_session(self):        # Esta função é chamada quando o Chefe clicar no botão "START MISSION"(OU INICIAR SESSAO!!!!) na interface.
        # Gera um ID único para a sessão (ex: timestamp)
        session_id = datetime.now().strftime("%Y%m%d_%H%M%S") # Cria um nome único para a missão baseado na data e hora atual (ex: 20251127_163000). 
        self.current_session = Session(session_id) # cria uma nova instância da classe Session (caixa vazia) e guarda-a na memória.
        # A partir deste momento, o sistema está pronto para receber bombeiros e alertas, porque a current_session deixou de ser None.
        print(f"Sessão {session_id} iniciada.")     # so para testar se está a funcionar 

    def end_session(self): # Termina a sessão e limpa os dados
        if self.current_session:
            print(f"A terminar sessão {self.current_session.session_id}...")
            # Aqui caso seja preciso entra a lógica para guardar o log na Cloud Database                
            self.current_session = None
        else:
            print("Nenhuma sessão ativa.")         






