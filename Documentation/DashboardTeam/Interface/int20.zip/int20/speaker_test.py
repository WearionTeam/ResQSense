import os
import time

from speaker_controller import SpeakerController


def main():
    try:
        pin = int(os.getenv("RESQSENSE_SPEAKER_PIN", "18"))
    except ValueError:
        pin = 18

    speaker = SpeakerController(pin=pin)
    if not speaker.available():
        print(f"Speaker indisponivel no GPIO {pin}. Verifica gpiozero/RPi.GPIO e a ligacao fisica.")
        return

    print(f"Teste do speaker no GPIO {pin}")
    print("A tocar sequencia curta...")
    speaker.emergency_burst()
    time.sleep(1.2)

    print("A tocar alarme continuo durante 4 segundos...")
    speaker.set_alarm(True)
    time.sleep(4)
    speaker.set_alarm(False)
    speaker.cleanup()
    print("Teste concluido.")


if __name__ == "__main__":
    main()
