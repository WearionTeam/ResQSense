import time

from magnetometer_controller import MagnetometerController


def main():
    controller = MagnetometerController(update_interval_sec=0.2)
    if not controller.available():
        print("Magnetometro indisponivel. Verifica o BNO08x, I2C e dependencias Python.")
        if controller.last_error:
            print(f"Erro: {controller.last_error}")
        return

    controller.start()
    print("Leitura de heading do magnetometro iniciada. Ctrl+C para sair.")
    try:
        while True:
            print(f"Heading: {controller.get_heading_degrees():6.1f} deg")
            time.sleep(0.4)
    except KeyboardInterrupt:
        pass
    finally:
        controller.stop()


if __name__ == "__main__":
    main()
