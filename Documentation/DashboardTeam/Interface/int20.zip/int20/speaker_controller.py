import threading
import time


class SpeakerController:
    """
    Passive speaker / buzzer controller for Raspberry Pi GPIO.

    Preferred backend:
    1) gpiozero.TonalBuzzer
    2) RPi.GPIO PWM
    """

    def __init__(self, pin=18):
        self.pin = pin
        self.backend = None
        self.device = None
        self.tone_factory = None
        self.gpio = None
        self.pwm = None
        self._alarm_active = False
        self._alarm_thread = None
        self._burst_running = False
        self._last_burst_ts = 0.0
        self._min_burst_interval_sec = 1.5
        self._lock = threading.RLock()

        try:
            from gpiozero import TonalBuzzer  # type: ignore
            from gpiozero.tones import Tone  # type: ignore

            self.device = TonalBuzzer(self.pin)
            self.tone_factory = Tone
            self.backend = "gpiozero_tonal"
            return
        except Exception:
            pass

        try:
            import RPi.GPIO as GPIO  # type: ignore

            self.gpio = GPIO
            self.gpio.setwarnings(False)
            self.gpio.setmode(self.gpio.BCM)
            self.gpio.setup(self.pin, self.gpio.OUT)
            self.pwm = self.gpio.PWM(self.pin, 880)
            self.pwm.start(0)
            self.backend = "rpi_gpio_pwm"
        except Exception:
            self.backend = None

    def available(self):
        return self.backend is not None

    def play_tone(self, frequency=880, duty_cycle=50):
        if self.backend == "gpiozero_tonal" and self.device and self.tone_factory:
            self.device.play(self.tone_factory.from_frequency(float(frequency)))
        elif self.backend == "rpi_gpio_pwm" and self.pwm:
            self.pwm.ChangeFrequency(max(1, int(frequency)))
            self.pwm.ChangeDutyCycle(max(0, min(100, duty_cycle)))

    def stop(self):
        if self.backend == "gpiozero_tonal" and self.device:
            self.device.stop()
        elif self.backend == "rpi_gpio_pwm" and self.pwm:
            self.pwm.ChangeDutyCycle(0)

    def set_alarm(self, is_active):
        if not self.available():
            return

        if is_active:
            if self._alarm_active:
                return
            self._alarm_active = True
            self._alarm_thread = threading.Thread(target=self._alarm_worker, daemon=True)
            self._alarm_thread.start()
            return

        self._alarm_active = False
        self.stop()

    def emergency_burst(self):
        if not self.available():
            return

        now = time.monotonic()
        if now - self._last_burst_ts < self._min_burst_interval_sec:
            return
        self._last_burst_ts = now

        with self._lock:
            if self._burst_running:
                return
            self._burst_running = True

        threading.Thread(target=self._burst_worker, daemon=True).start()

    def _play_pattern_step(self, frequency, on_time, off_time):
        with self._lock:
            self.play_tone(frequency)
            time.sleep(on_time)
            self.stop()
        time.sleep(off_time)

    def _alarm_worker(self):
        try:
            while self._alarm_active:
                self._play_pattern_step(880, 0.14, 0.06)
                if not self._alarm_active:
                    break
                self._play_pattern_step(988, 0.14, 0.30)
        finally:
            self.stop()

    def _burst_worker(self):
        try:
            for frequency, on_time, off_time in (
                (1046, 0.08, 0.05),
                (1318, 0.08, 0.05),
                (1568, 0.12, 0.08),
            ):
                self._play_pattern_step(frequency, on_time, off_time)
        finally:
            with self._lock:
                self._burst_running = False
            if self._alarm_active:
                self.play_tone(880)
                time.sleep(0.02)
                self.stop()

    def cleanup(self):
        self._alarm_active = False
        try:
            self.stop()
        except Exception:
            pass

        if self.backend == "gpiozero_tonal" and self.device:
            try:
                self.device.close()
            except Exception:
                pass

        if self.backend == "rpi_gpio_pwm" and self.pwm:
            try:
                self.pwm.stop()
            except Exception:
                pass

        if self.backend == "rpi_gpio_pwm" and self.gpio:
            try:
                self.gpio.cleanup(self.pin)
            except Exception:
                pass
