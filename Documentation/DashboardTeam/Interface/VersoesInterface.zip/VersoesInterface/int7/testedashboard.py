import tkinter as tk
from tkinter import ttk, messagebox
import datetime
import math
import random
import time
import tkinter as tk

# IMPORTAÇÃO DOS OUTROS SCRIPTS
from models import DashboardController, Operator
from simulation import HardwareSimulator

# --- ADICIONA ISTO PARA O BUZZER ---
try:
    from gpiozero import Buzzer
    GPIO_DISPONIVEL = True
except ImportError:
    GPIO_DISPONIVEL = False

class ResQSenseApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ResQSense.exe")    
        self.root.geometry("1000x600")

        # INICIALIZA O BUZZER FISICO
        if GPIO_DISPONIVEL:
            self.pino_buzzer = Buzzer(17)
        else:
            self.pino_buzzer = None
        
        # INICIALIZA O CONTROLADOR (BACKEND)
        self.controller = DashboardController()
        
        # Cores baseadas no wireframe original
        self.bg_color = "#d9d9d9"
        self.header_color = "#d9d9d9"
        self.sidebar_color = "#d9d9d9"
        self.alert_color = "#e74c3c" # Vermelho para alertas
        self.safe_color = "#2ecc71"  # Verde para seguro
        self.avatar_fill = "white"   # Cor de preenchimento do boneco
        self.avatar_outline = "black"
        
        self.root.configure(bg=self.bg_color)
        
        self.team_leader_name = ""
        
        # Lista Híbrida: { "id": "1", "name": "...", "angle": 0.0, "dist": 0.5, "logic_ref": OperatorObject, "is_leader": False }
        self.firefighters = []

        # Estado da aplicação
        self.edit_mode = False 
        self.menu_open = False 
        self.blink_state = False 

        # Inicia com a tela de Login
        self.show_login_screen()

    def clear_window(self):
        """Limpa todos os widgets da janela atual"""
        for widget in self.root.winfo_children():
            widget.destroy()

    def draw_standard_avatar(self, canvas, x, y, width, height):
        """Desenha um boneco padronizado (estilo perfil) do 1º código"""
        pad = 2
        w = width - 2*pad
        h = height - 2*pad
        x0 = x + pad
        y0 = y + pad
        
        cx = x0 + w // 2
        
        head_r = h * 0.20
        head_cy = y0 + (h * 0.3) 
        
        canvas.create_oval(cx - head_r, head_cy - head_r, 
                           cx + head_r, head_cy + head_r, 
                           fill=self.avatar_fill, outline=self.avatar_outline, width=2)
        
        body_w = w * 0.7  
        body_h = h * 0.45 
        
        arc_x0 = cx - body_w / 2
        arc_x1 = cx + body_w / 2
        arc_y0 = head_cy + head_r + (h * 0.05) 
        arc_y1 = arc_y0 + (body_h * 2) 
        
        canvas.create_arc(arc_x0, arc_y0, arc_x1, arc_y1, 
                          start=0, extent=180, style=tk.CHORD, 
                          fill=self.avatar_fill, outline=self.avatar_outline, width=2)

    # ==========================================
    # TELA 1: LOGIN
    # ==========================================
    def show_login_screen(self):
        self.clear_window()
        self.root.configure(bg=self.bg_color)
        
        login_frame = tk.Frame(self.root, bg=self.bg_color, relief="solid", bd=1, width=350, height=450)
        login_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        login_frame.pack_propagate(False)

        avatar_canvas = tk.Canvas(login_frame, width=140, height=140, bg=self.bg_color, highlightthickness=0)
        avatar_canvas.pack(pady=(40, 30))
        self.draw_standard_avatar(avatar_canvas, 10, 10, 120, 120)

        fs_frame = tk.Frame(login_frame, bg=self.bg_color, relief="solid", bd=1)
        fs_frame.pack(fill=tk.X, padx=40, pady=(0, 15))
        tk.Label(fs_frame, text="Fire Station:", bg=self.bg_color, font=("Arial", 10)).pack(side=tk.LEFT, padx=5, pady=8)
        self.station_entry = tk.Entry(fs_frame, bg=self.bg_color, bd=0, highlightthickness=0, font=("Arial", 10))
        self.station_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

        name_frame = tk.Frame(login_frame, bg=self.bg_color, relief="solid", bd=1)
        name_frame.pack(fill=tk.X, padx=40, pady=(0, 25))
        tk.Label(name_frame, text="Name/ID:", bg=self.bg_color, font=("Arial", 10)).pack(side=tk.LEFT, padx=5, pady=8)
        self.leader_name_entry = tk.Entry(name_frame, bg=self.bg_color, bd=0, highlightthickness=0, font=("Arial", 10))
        self.leader_name_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

        btn_login = tk.Button(login_frame, text="Log in", bg=self.bg_color, relief="solid", bd=1, font=("Arial", 10),
                              command=self.verify_login)
        btn_login.pack(ipadx=30, ipady=5)

    def verify_login(self):
        leader_name = self.leader_name_entry.get().strip()
        
        if not leader_name:
            messagebox.showwarning("Aviso", "Por favor, introduza o Name/ID do Chefe de Equipa.")
            return
            
        self.team_leader_name = leader_name
        self.controller.start_new_session()
        self.show_dashboard_wireframe()
        
        self.add_leader_to_team(self.team_leader_name)

    # ==========================================
    # TELA 2: DASHBOARD
    # ==========================================
    def show_dashboard_wireframe(self):
        self.clear_window()
        self.root.configure(bg=self.bg_color)

        header_frame = tk.Frame(self.root, bg=self.header_color, height=60)
        header_frame.pack(fill=tk.X, side=tk.TOP)
        
        separator = tk.Frame(self.root, bg="black", height=2)
        separator.pack(fill=tk.X, side=tk.TOP)

        self.lbl_menu = tk.Label(header_frame, text="☰", font=("Arial", 24), bg=self.header_color, cursor="hand2")
        self.lbl_menu.pack(side=tk.LEFT, padx=15)
        self.lbl_menu.bind("<Button-1>", self.toggle_menu)
        
        tk.Frame(header_frame, bg="black", width=2, height=40).pack(side=tk.LEFT, padx=5, pady=10)

        tk.Label(header_frame, text="ResQSense", font=("Arial", 16), bg=self.header_color).pack(side=tk.LEFT, padx=10)
        tk.Label(header_frame, text="Wearion", font=("Arial", 10), bg=self.header_color, fg="#555").pack(side=tk.LEFT, pady=(5,0))

        profile_canvas = tk.Canvas(header_frame, width=50, height=50, bg=self.header_color, highlightthickness=0)
        profile_canvas.pack(side=tk.RIGHT, padx=15)
        self.draw_standard_avatar(profile_canvas, 0, 0, 50, 50)

        self.time_label = tk.Label(header_frame, text="00:00", font=("Arial", 14), bg=self.header_color)
        self.time_label.pack(side=tk.RIGHT, padx=20)
        self.update_clock()

        main_container = tk.Frame(self.root, bg=self.bg_color)
        main_container.pack(fill=tk.BOTH, expand=True)

        self.sidebar = tk.Frame(main_container, bg=self.sidebar_color, width=220)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.pack_propagate(False)

        tk.Frame(self.sidebar, bg="black", width=4).pack(side=tk.RIGHT, fill=tk.Y)

        self.content_sidebar = tk.Frame(self.sidebar, bg=self.sidebar_color)
        self.content_sidebar.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        tk.Label(self.content_sidebar, text="Operational", font=("Arial", 14), bg=self.sidebar_color, anchor="w").pack(fill=tk.X, pady=(10, 5))
        
        self.firefighter_list_frame = tk.Frame(self.content_sidebar, bg=self.sidebar_color)
        self.firefighter_list_frame.pack(fill=tk.BOTH, expand=True)

        btn_plus = tk.Button(self.content_sidebar, text="+", font=("Arial", 24, "bold"), bg="#e0e0e0", 
                             relief="solid", borderwidth=1, command=self.open_add_firefighter_window)
        btn_plus.pack(fill=tk.X, pady=10, ipady=5, side=tk.BOTTOM)

        map_area = tk.Frame(main_container, bg=self.bg_color)
        map_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(map_area, bg=self.bg_color, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", self.draw_radar)

        footer = tk.Frame(self.root, bg="black", height=5)
        footer.pack(fill=tk.X, side=tk.BOTTOM)

        self.menu_frame = tk.Frame(self.root, bg="#f0f0f0", relief="solid", bd=1)
        btn_edit = tk.Button(self.menu_frame, text="Edit", font=("Arial", 12), anchor="w", bg="#f0f0f0", bd=0, padx=10, command=self.toggle_edit_mode)
        btn_edit.pack(fill=tk.X, pady=2)
        btn_resources = tk.Button(self.menu_frame, text="Additional Resources", font=("Arial", 12), anchor="w", bg="#f0f0f0", bd=0, padx=10)
        btn_resources.pack(fill=tk.X, pady=2)

        self.update_simulation_cycle()

    # ==========================================
    # LÓGICA DO MENU E EDIÇÃO
    # ==========================================
    def toggle_menu(self, event):
        if self.menu_open:
            self.menu_frame.place_forget()
            self.menu_open = False
        else:
            self.menu_frame.place(x=10, y=60, width=200, height=80)
            self.menu_frame.lift()
            self.menu_open = True

    def toggle_edit_mode(self):
        self.edit_mode = not self.edit_mode
        self.refresh_sidebar_list()
        self.menu_frame.place_forget()
        self.menu_open = False

    def remove_firefighter(self, ff_to_remove):
        if ff_to_remove.get('is_leader', False): return 

        if ff_to_remove in self.firefighters:
            self.firefighters.remove(ff_to_remove)
            self.refresh_sidebar_list()
            self.draw_radar()

    # ==========================================
    # LÓGICA DE SIMULAÇÃO
    # ==========================================
    def update_simulation_cycle(self):
        self.blink_state = not self.blink_state

        alerta_ativo = False # Variável para controlar o som
        if self.firefighters:
            for ff in self.firefighters:
                data = HardwareSimulator.get_fake_data()
                op_logic = ff['logic_ref']
                op_logic.update_detail(data)

                # VERIFICA ESTADO CRÍTICO 
                is_critical, _ = op_logic.check_health_status()
                if is_critical:
                   self.pino_buzzer.beep(on_time=0.1, off_time=0.1, n=5) #alerta_ativo = True

                if not ff.get('is_leader', False):
                    ff['angle'] += random.uniform(-0.1, 0.1)
                    ff['dist'] = max(0.1, min(0.9, ff['dist'] + random.uniform(-0.02, 0.02)))
            
            # --- CONTROLO DO BUZZER ---
            if self.pino_buzzer:
                if alerta_ativo:
                    self.pino_buzzer.on()  # Liga o som se houver perigo 
                else:
                    self.pino_buzzer.off() # Silêncio se todos estiverem bem
            self.refresh_sidebar_list()
            self.draw_radar()

        self.root.after(2000, self.update_simulation_cycle)

    # ==========================================
    # GESTÃO DA EQUIPA E POPUP
    # ==========================================
    def add_leader_to_team(self, name):
        leader_logic = Operator(id=0, name=name, vest_id="LDR")
        leader_dict = {
            "id": "C",
            "name": name,
            "angle": 0.0,
            "dist": 0.0,
            "logic_ref": leader_logic,
            "is_leader": True
        }
        self.firefighters.append(leader_dict)
        self.refresh_sidebar_list()
        self.draw_radar()

    def open_add_firefighter_window(self):
        # Passo 1: Conta os operacionais (excluindo o líder) para não passar do limite de 4
        current_ops = [f for f in self.firefighters if not f.get('is_leader', False)]
        if len(current_ops) >= 4:
            messagebox.showwarning("Aviso", "Atingiu o número máximo de 4 operacionais.")
            return

        popup = tk.Toplevel(self.root)
        popup.title("Adicionar Operacional")
        popup.geometry("350x450") # Um pouco menor para ficar mais estético (como o login)
        popup.configure(bg=self.bg_color)
        
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 175
        y = self.root.winfo_y() + 50  
        popup.geometry(f"+{x}+{y}")

        container = tk.Frame(popup, bg=self.bg_color, relief="solid", bd=1, padx=20, pady=20)
        container.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)

        icon_canvas = tk.Canvas(container, width=100, height=100, bg=self.bg_color, highlightthickness=0)
        icon_canvas.pack(pady=10)
        self.draw_standard_avatar(icon_canvas, 0, 0, 100, 100)

        # Atualização dos textos baseados na Imagem que enviaste
        tk.Label(container, text="Fire Station:", bg=self.bg_color, anchor="w", font=("Arial", 10)).pack(fill=tk.X)
        entry_station = tk.Entry(container, relief="solid", bd=1)
        entry_station.pack(fill=tk.X, pady=(0, 15), ipady=3)

        tk.Label(container, text="Name/ID:", bg=self.bg_color, anchor="w", font=("Arial", 10)).pack(fill=tk.X)
        entry_name = tk.Entry(container, relief="solid", bd=1)
        entry_name.pack(fill=tk.X, pady=(0, 20), ipady=3)

        def confirm_add():
            f_station = entry_station.get().strip()
            f_name = entry_name.get().strip()
            
            if f_station and f_name:
                # Passo 2: Geração Automática do ID. Se já temos 2 operacionais, este será o 3.
                ops_count = len([f for f in self.firefighters if not f.get('is_leader', False)])
                auto_id = str(ops_count + 1)
                
                self.add_firefighter(auto_id, f_name)
                popup.destroy()
            else:
                messagebox.showwarning("Aviso", "Preencha todos os campos!")

        # Passo 3: Texto do Botão Atualizado
        btn_add = tk.Button(container, text="Add Firefighter", bg="#d0d0d0", relief="solid", bd=1, command=confirm_add)
        btn_add.pack(ipadx=20, ipady=5)

    def add_firefighter(self, f_number, f_name):
        new_op_logic = Operator(id=int(f_number) if f_number.isdigit() else 0, name=f_name, vest_id=f_number)
        
        if self.controller.current_session:
            self.controller.current_session.add_firefighter_to_team(new_op_logic)

        angle = random.uniform(0, 2 * math.pi)
        distance = random.uniform(0.2, 0.8) 
        
        new_ff = {
            "id": f_number,
            "name": f_name,
            "angle": angle,
            "dist": distance,
            "logic_ref": new_op_logic,
            "is_leader": False
        }
        self.firefighters.append(new_ff)
        self.refresh_sidebar_list()
        self.draw_radar()

    # ==========================================
    # ATUALIZAR SIDEBAR
    # ==========================================
    def refresh_sidebar_list(self):
        for widget in self.firefighter_list_frame.winfo_children():
            widget.destroy()
            
        for ff in self.firefighters:
            op_logic = ff['logic_ref']
            bio = op_logic.biometrics
            
            is_critical, warnings = op_logic.check_health_status()
            is_leader = ff.get('is_leader', False)

            card_bg = "#ffcccc" if is_critical else self.bg_color
            border_thick = 2 if is_critical else 1

            card = tk.Frame(self.firefighter_list_frame, bg=card_bg, relief="solid", bd=border_thick, pady=5, padx=5)
            card.pack(fill=tk.X, pady=5)
            
            header = tk.Frame(card, bg=card_bg)
            header.pack(fill=tk.X)

            icon_canvas = tk.Canvas(header, width=30, height=30, bg=card_bg, highlightthickness=0)
            icon_canvas.pack(side=tk.LEFT, padx=(0,5))
            self.draw_standard_avatar(icon_canvas, 0, 0, 30, 30)

            # Mostra o Nome e ID do operacional
            display_text = f"{ff['name']} / {ff['id']}"
            tk.Label(header, text=display_text, font=("Arial", 11, "bold"), bg=card_bg).pack(side=tk.LEFT, padx=5)
            
            if self.edit_mode and not is_leader:
                btn_del = tk.Button(header, text="-", font=("Arial", 10, "bold"), 
                                    bg="white", fg="red", relief="solid", bd=1, 
                                    width=2, cursor="hand2",
                                    command=lambda f=ff: self.remove_firefighter(f))
                btn_del.pack(side=tk.RIGHT, padx=5)

            info_frame = tk.Frame(card, bg=card_bg)
            info_frame.pack(fill=tk.X, pady=(5,0))

            hr_color = "red" if bio.heart_rate > 105 else "black"
            o2_color = "blue" if bio.oxygenation < 95 else "black"
            temp_color = "#d35400" if bio.temperature > 37.8 else "black"

            f1 = tk.Frame(info_frame, bg=card_bg)
            f1.pack(side=tk.LEFT, fill=tk.X, expand=True)
            tk.Label(f1, text="HR", font=("Arial", 7), bg=card_bg, fg="#555").pack()
            tk.Label(f1, text=f"{bio.heart_rate}", font=("Arial", 10, "bold"), bg=card_bg, fg=hr_color).pack()

            f2 = tk.Frame(info_frame, bg=card_bg)
            f2.pack(side=tk.LEFT, fill=tk.X, expand=True)
            tk.Label(f2, text="SpO2", font=("Arial", 7), bg=card_bg, fg="#555").pack()
            tk.Label(f2, text=f"{bio.oxygenation}%", font=("Arial", 10, "bold"), bg=card_bg, fg=o2_color).pack()

            f3 = tk.Frame(info_frame, bg=card_bg)
            f3.pack(side=tk.LEFT, fill=tk.X, expand=True)
            tk.Label(f3, text="Temp", font=("Arial", 7), bg=card_bg, fg="#555").pack()
            tk.Label(f3, text=f"{bio.temperature}º", font=("Arial", 10, "bold"), bg=card_bg, fg=temp_color).pack()

            if is_critical:
                warn_text = " | ".join(warnings)
                tk.Label(card, text=f"⚠️ {warn_text}", font=("Arial", 8, "bold"), bg=card_bg, fg="red").pack(pady=(2,0))

    # ==========================================
    # ATUALIZAR RADAR
    # ==========================================
    def draw_radar(self, event=None):
        self.canvas.delete("all")
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        
        if w <= 10 or h <= 10: return
        
        cx, cy = w // 2, h // 2

        self.canvas.create_line(0, cy, w, cy, fill="black", width=1)
        self.canvas.create_line(cx, 0, cx, h, fill="black", width=1)

        margin = 80 
        max_radius = min(w, h) // 2 - margin 
        if max_radius < 10: max_radius = 10

        for i in range(1, 6):
            r = (max_radius / 5) * i
            self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r, outline="black", width=1)

        compass_x, compass_y = 40, 40
        self.canvas.create_polygon(compass_x, compass_y-20, compass_x-10, compass_y, compass_x+10, compass_y, fill="#e74c3c", outline="black")
        self.canvas.create_text(compass_x - 15, compass_y - 20, text="N", font=("Arial", 10, "bold"))
        self.canvas.create_polygon(compass_x, compass_y+20, compass_x-10, compass_y, compass_x+10, compass_y, fill="white", outline="black")
        self.canvas.create_text(compass_x - 15, compass_y + 15, text="S", font=("Arial", 10))
        
        self.canvas.create_line(0, h-40, w, h-40, fill="black", width=4)
        
        rect_w, rect_h = 120, 30
        self.canvas.create_rectangle(0, h-40-rect_h, rect_w, h-40, fill="#ffcc00", outline="black", width=2)
        self.canvas.create_text(rect_w/2, h-40-(rect_h/2), text="⚠️ Warnings", font=("Arial", 10, "bold"))

        scale_x_start = w - 100
        scale_x_end = w - 20
        scale_y = h - 60
        self.canvas.create_text(scale_x_start, scale_y - 10, text="0 m", font=("Arial", 8))
        self.canvas.create_text(scale_x_end, scale_y - 10, text="40 m", font=("Arial", 8))
        self.canvas.create_line(scale_x_start, scale_y, scale_x_start, scale_y+5, fill="black", width=1)
        self.canvas.create_line(scale_x_end, scale_y, scale_x_end, scale_y+5, fill="black", width=1)
        self.canvas.create_line(scale_x_start, scale_y, scale_x_end, scale_y, fill="black", width=1)

        for ff in self.firefighters:
            is_leader = ff.get('is_leader', False)
            node_r = 12 # Tamanho do ponto verde no radar
            
            if is_leader:
                self.canvas.create_oval(cx - node_r, cy - node_r, cx + node_r, cy + node_r, fill=self.safe_color, outline="black")
                self.canvas.create_text(cx, cy, text="C", font=("Arial", 10, "bold"))
                continue 
                
            r_pixels = ff['dist'] * max_radius
            pos_x = cx + r_pixels * math.cos(ff['angle'])
            pos_y = cy + r_pixels * math.sin(ff['angle'])
            
            op_logic = ff['logic_ref']
            is_critical, _ = op_logic.check_health_status()

            color = self.safe_color
            if is_critical:
                color = self.alert_color
                if self.blink_state:
                    self.canvas.create_oval(pos_x - 16, pos_y - 16, pos_x + 16, pos_y + 16, outline="red", width=2)
            
            # Passo 4: O número do operacional fica agora DENTRO do ponto do radar
            self.canvas.create_oval(pos_x - node_r, pos_y - node_r, pos_x + node_r, pos_y + node_r, fill=color, outline="black")
            self.canvas.create_text(pos_x, pos_y, text=ff['id'], font=("Arial", 10, "bold"), fill="black")

    def update_clock(self):
        now = datetime.datetime.now().strftime("%H:%M")
        try:
            self.time_label.config(text=now)
            self.root.after(1000, self.update_clock)
        except:
            pass

if __name__ == "__main__":
    root = tk.Tk()
    app = ResQSenseApp(root)
    root.mainloop()