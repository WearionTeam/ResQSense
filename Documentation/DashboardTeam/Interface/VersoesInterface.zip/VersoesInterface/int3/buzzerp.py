import RPi.GPIO as GPIO
import time

PINO_BUZZER = 18
FREQUENCIA_HZ = 200 

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(PINO_BUZZER, GPIO.OUT)

pwm = GPIO.PWM(PINO_BUZZER, FREQUENCIA_HZ)

try:
    while True:
        pwm.start(50)
        time.sleep(0.5)
        pwm.stop()
        time.sleep(0.5)
except KeyboardInterrupt:
    pass
finally:
    GPIO.cleanup()