import RPi.GPIO as GPIO
import time

PINO_BUZZER = 18

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(PINO_BUZZER, GPIO.OUT)

try:
    while True:
        GPIO.output(PINO_BUZZER, GPIO.HIGH)
        time.sleep(0.2)
        GPIO.output(PINO_BUZZER, GPIO.LOW)
        time.sleep(0.2)
except KeyboardInterrupt:
    pass
finally:
    GPIO.cleanup()