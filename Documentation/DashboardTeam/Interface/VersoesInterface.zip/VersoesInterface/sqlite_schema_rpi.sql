-- ============================================
-- ResQSense Wearion - SQLite Schema (Raspberry Pi)
-- Base de dados operacional / tempo real
-- ============================================

-- Team Leaders (cache local para autenticação)
CREATE TABLE IF NOT EXISTS team_leader (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    pin_hash    TEXT NOT NULL
);

-- Operadores / Bombeiros
CREATE TABLE IF NOT EXISTS operator (
    id                      INTEGER PRIMARY KEY,
    name                    TEXT NOT NULL,
    vest_id                 TEXT UNIQUE NOT NULL,
    is_alerting             INTEGER DEFAULT 0,  -- 0 = false, 1 = true (SQLite não tem boolean)
    baseline_heart_rate     INTEGER,
    baseline_temperature    REAL,
    baseline_oxygenation    INTEGER
);

-- Sessão ativa
CREATE TABLE IF NOT EXISTS session (
    session_id      TEXT PRIMARY KEY,
    leader_id       INTEGER NOT NULL,
    started_at      TEXT DEFAULT (datetime('now', 'localtime')),
    ended_at        TEXT,
    FOREIGN KEY (leader_id) REFERENCES team_leader(id)
);

-- Operadores atribuídos a uma sessão
CREATE TABLE IF NOT EXISTS session_operator (
    session_id      TEXT NOT NULL,
    operator_id     INTEGER NOT NULL,
    joined_at       TEXT DEFAULT (datetime('now', 'localtime')),
    PRIMARY KEY (session_id, operator_id),
    FOREIGN KEY (session_id) REFERENCES session(session_id),
    FOREIGN KEY (operator_id) REFERENCES operator(id)
);

-- Dados biométricos (chegam em tempo real dos coletes)
CREATE TABLE IF NOT EXISTS biometric_data (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    operator_id             INTEGER NOT NULL,
    session_id              TEXT NOT NULL,
    heart_rate              INTEGER,
    oxygenation             INTEGER,
    temperature             REAL,
    processing_delay_sec    INTEGER,
    recorded_at             TEXT DEFAULT (datetime('now', 'localtime')),
    synced                  INTEGER DEFAULT 0,  -- 0 = por sincronizar, 1 = sincronizado
    FOREIGN KEY (operator_id) REFERENCES operator(id),
    FOREIGN KEY (session_id) REFERENCES session(session_id)
);

-- Dados de localização (chegam em tempo real dos coletes)
CREATE TABLE IF NOT EXISTS location_data (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    operator_id     INTEGER NOT NULL,
    session_id      TEXT NOT NULL,
    distance        REAL,
    height          REAL,
    lat             REAL,
    long            REAL,
    recorded_at     TEXT DEFAULT (datetime('now', 'localtime')),
    synced          INTEGER DEFAULT 0,
    FOREIGN KEY (operator_id) REFERENCES operator(id),
    FOREIGN KEY (session_id) REFERENCES session(session_id)
);

-- Alertas (Man Down, ritmo cardíaco rápido, queda, etc.)
CREATE TABLE IF NOT EXISTS alert (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    operator_id     INTEGER NOT NULL,
    session_id      TEXT NOT NULL,
    timestamp       TEXT DEFAULT (datetime('now', 'localtime')),
    description     TEXT NOT NULL,
    synced          INTEGER DEFAULT 0,
    FOREIGN KEY (operator_id) REFERENCES operator(id),
    FOREIGN KEY (session_id) REFERENCES session(session_id)
);

-- Tentativas de login falhadas
CREATE TABLE IF NOT EXISTS failed_login_attempt (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    leader_id       INTEGER,
    attempted_at    TEXT DEFAULT (datetime('now', 'localtime')),
    synced          INTEGER DEFAULT 0
);

-- Índices para consultas rápidas na interface
CREATE INDEX IF NOT EXISTS idx_biometric_operator ON biometric_data(operator_id, recorded_at);
CREATE INDEX IF NOT EXISTS idx_location_operator ON location_data(operator_id, recorded_at);
CREATE INDEX IF NOT EXISTS idx_alert_session ON alert(session_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_biometric_synced ON biometric_data(synced);
CREATE INDEX IF NOT EXISTS idx_location_synced ON location_data(synced);
CREATE INDEX IF NOT EXISTS idx_alert_synced ON alert(synced);
