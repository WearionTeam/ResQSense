import tkinter as tk
from tkinter import messagebox

from autocomplete_entry import AutocompleteEntry
from firestation_database import get_fire_station_names
from virtual_keyboard import apply_virtual_text_key, build_virtual_keyboard


def open_add_firefighter_dialog(app):
    current_ops = [f for f in app.firefighters if not f.get("is_leader", False)]
    if len(current_ops) >= app.max_operationals:
        messagebox.showwarning(
            app.t("warning_title"),
            app.t("warn_max_ops", max_ops=app.max_operationals),
        )
        return

    popup = tk.Toplevel(app.root)
    popup.title(app.t("add_operational_title"))
    popup.configure(bg=app.bg_color)
    popup.transient(app.root)
    popup.grab_set()
    popup.resizable(False, False)

    screen_w = app.root.winfo_screenwidth()
    screen_h = app.root.winfo_screenheight()
    popup_w = min(760, max(620, screen_w - 20))
    popup_h = min(430, max(340, screen_h - 90))
    compact_popup = popup_h <= 420
    x = max(0, (screen_w - popup_w) // 2)
    y = max(0, (screen_h - popup_h) // 2)
    popup.geometry(f"{popup_w}x{popup_h}+{x}+{y}")

    content = tk.Frame(popup, bg=app.bg_color)
    content.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

    form_w = max(280, int(popup_w * 0.42))
    form_panel = tk.Frame(content, bg=app.bg_color, relief="solid", bd=1, width=form_w)
    form_panel.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 10))
    form_panel.pack_propagate(False)

    keyboard_panel = tk.Frame(content, bg=app.bg_color, relief="solid", bd=1)
    keyboard_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    keyboard_panel.pack_propagate(False)

    form_body = tk.Frame(form_panel, bg=app.bg_color)
    form_body.pack(fill=tk.BOTH, expand=True, padx=14, pady=(10, 6))

    if not compact_popup:
        icon_canvas = tk.Canvas(form_body, width=82, height=82, bg=app.bg_color, highlightthickness=0)
        icon_canvas.pack(pady=(0, 8))
        app.draw_standard_avatar(icon_canvas, 0, 0, 82, 82)

    tk.Label(form_body, text=app.t("fire_station"), bg=app.bg_color, anchor="w", font=("Arial", 10)).pack(fill=tk.X)
    entry_station = AutocompleteEntry(
        form_body,
        options=get_fire_station_names(),
        bg=app.bg_color,
    )
    entry_station.pack(fill=tk.X, pady=(0, 8 if compact_popup else 12))
    if app.fire_station_name:
        entry_station.set(app.fire_station_name)

    tk.Label(form_body, text=app.t("name_id"), bg=app.bg_color, anchor="w", font=("Arial", 10)).pack(fill=tk.X)
    entry_name = tk.Entry(form_body, relief="solid", bd=1, font=("Arial", 12))
    entry_name.pack(fill=tk.X, pady=(0, 8 if compact_popup else 12), ipady=4)

    def confirm_add():
        f_station = entry_station.get().strip()
        f_name = entry_name.get().strip()

        if f_station and f_name:
            ops_count = len([f for f in app.firefighters if not f.get("is_leader", False)])
            auto_id = str(ops_count + 1)
            app.add_firefighter(auto_id, f_name)
            popup.destroy()
        else:
            messagebox.showwarning(app.t("warning_title"), app.t("warn_fill_all"))

    form_actions = tk.Frame(form_panel, bg=app.bg_color)
    form_actions.pack(fill=tk.X, side=tk.BOTTOM, padx=14, pady=(0, 10))

    btn_add = tk.Button(
        form_actions,
        text=app.t("add_firefighter"),
        bg="#d0d0d0",
        relief="solid",
        bd=2,
        font=("Arial", 12, "bold"),
        command=confirm_add,
    )
    btn_add.pack(fill=tk.X, ipady=7)

    popup_input_ref = {"widget": None}
    station_input = entry_station.get_input_widget()

    def set_popup_active_input(widget):
        popup_input_ref["widget"] = widget

    def focus_entry_end(entry_widget):
        try:
            entry_widget.focus_set()
            entry_widget.icursor(tk.END)
        except tk.TclError:
            return

    def focus_add_station_input(_event=None):
        entry_station.focus_input()
        set_popup_active_input(station_input)

    def focus_add_name_input(_event=None):
        entry_station.hide_suggestions()
        popup.after_idle(lambda: focus_entry_end(entry_name))
        set_popup_active_input(entry_name)

    def on_popup_name_focus(_event=None):
        entry_station.hide_suggestions()
        set_popup_active_input(entry_name)

    entry_station.bind("<<AutocompleteSelected>>", focus_add_name_input)
    station_input.bind("<FocusIn>", lambda _e: set_popup_active_input(station_input), add="+")
    entry_name.bind("<FocusIn>", on_popup_name_focus)
    entry_name.bind("<Button-1>", focus_add_name_input)
    popup.bind("<Escape>", lambda _e: entry_station.hide_suggestions())

    def handle_popup_virtual_key(key):
        target = popup_input_ref["widget"]
        if not target or not target.winfo_exists():
            focus_add_station_input()
            target = popup_input_ref["widget"]

        if not target:
            return

        def handle_enter(current_target):
            if current_target == station_input:
                focus_add_name_input()
            else:
                confirm_add()

        apply_virtual_text_key(
            key=key,
            target=target,
            enter_handler=handle_enter,
            autocomplete_target=station_input,
            autocomplete_callback=entry_station.on_virtual_input,
        )

    compact_keyboard = popup_h < 420
    build_virtual_keyboard(
        keyboard_panel,
        bg_color=app.bg_color,
        compact_mode=compact_keyboard,
        key_handler=handle_popup_virtual_key,
        title_text="Keyboard",
    )
    popup.after(40, focus_add_station_input)
