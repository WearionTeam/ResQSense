def get_health_badge(status):
    if status == "critical":
        return "bad", "white"
    if status == "no_signal":
        return "ok", "#ffd166"
    return "good", "#1b7f3a"


def normalized_distance_to_meters(normalized_distance, max_distance_m):
    return max(0.0, normalized_distance) * max_distance_m
