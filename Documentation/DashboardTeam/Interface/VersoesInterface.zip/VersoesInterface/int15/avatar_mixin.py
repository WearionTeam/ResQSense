import tkinter as tk


class AvatarMixin:
    def draw_standard_avatar(self, canvas, x, y, width, height):
        """Desenha um boneco padronizado (estilo perfil)."""
        pad = 2
        w = width - 2 * pad
        h = height - 2 * pad
        x0 = x + pad
        y0 = y + pad

        cx = x0 + w // 2

        head_r = h * 0.20
        head_cy = y0 + (h * 0.3)

        canvas.create_oval(
            cx - head_r,
            head_cy - head_r,
            cx + head_r,
            head_cy + head_r,
            fill=self.avatar_fill,
            outline=self.avatar_outline,
            width=2,
        )

        body_w = w * 0.7
        body_h = h * 0.45

        arc_x0 = cx - body_w / 2
        arc_x1 = cx + body_w / 2
        arc_y0 = head_cy + head_r + (h * 0.05)
        arc_y1 = arc_y0 + (body_h * 2)

        canvas.create_arc(
            arc_x0,
            arc_y0,
            arc_x1,
            arc_y1,
            start=0,
            extent=180,
            style=tk.CHORD,
            fill=self.avatar_fill,
            outline=self.avatar_outline,
            width=2,
        )
