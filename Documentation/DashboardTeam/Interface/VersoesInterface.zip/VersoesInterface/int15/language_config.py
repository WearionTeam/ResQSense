﻿"""Language helpers for the ResQSense interface."""

from translations_data import LANGUAGE_OPTIONS, TRANSLATIONS


def translate(language_code, key, **kwargs):
    lang_map = TRANSLATIONS.get(language_code, {})
    base_map = TRANSLATIONS["en"]
    text = lang_map.get(key, base_map.get(key, key))
    if kwargs:
        try:
            return text.format(**kwargs)
        except (KeyError, ValueError):
            return text
    return text


def get_language_label(language_code):
    for label, code in LANGUAGE_OPTIONS:
        if code == language_code:
            return label
    return language_code

