import tkinter as tk


def build_virtual_keyboard(parent, bg_color, compact_mode, key_handler, title_text="Keyboard"):
    title = tk.Label(parent, text=title_text, bg=bg_color, font=("Arial", 11, "bold"), anchor="w")
    title.pack(fill=tk.X, padx=10, pady=(10, 4))

    keyboard = tk.Frame(parent, bg=bg_color)
    keyboard.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))

    rows = [
        ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "Back"],
        ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
        ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
        ["Z", "X", "C", "V", "B", "N", "M", "-", "_"],
        ["Space", "Clear", "Enter"],
    ]

    btn_font = ("Arial", 11 if compact_mode else 12, "bold")
    btn_height = 1 if compact_mode else 2

    for row in rows:
        row_frame = tk.Frame(keyboard, bg=bg_color)
        row_frame.pack(fill=tk.X, pady=3)

        col_index = 0
        for key in row:
            col_span = 1
            if key == "Space":
                col_span = 4
            elif key in ("Back", "Clear", "Enter"):
                col_span = 2

            btn = tk.Button(
                row_frame,
                text=key,
                font=btn_font,
                height=btn_height,
                relief="solid",
                bd=1,
                command=lambda k=key: key_handler(k),
            )
            btn.grid(row=0, column=col_index, columnspan=col_span, sticky="nsew", padx=2)
            for expand_col in range(col_index, col_index + col_span):
                row_frame.grid_columnconfigure(expand_col, weight=1)
            col_index += col_span


def apply_virtual_text_key(
    key,
    target,
    enter_handler,
    autocomplete_target=None,
    autocomplete_callback=None,
    digit_only_target=None,
):
    if not target or not target.winfo_exists():
        return

    target.focus_set()

    if key == "Enter":
        enter_handler(target)
        return

    if key == "Back":
        text_now = target.get()
        if not text_now:
            return
        try:
            cursor = target.index(tk.INSERT)
        except tk.TclError:
            cursor = len(text_now)
        if cursor <= 0:
            return
        target.delete(cursor - 1, cursor)
        if autocomplete_callback and target == autocomplete_target:
            autocomplete_callback()
        return

    if key == "Clear":
        target.delete(0, tk.END)
        if autocomplete_callback and target == autocomplete_target:
            autocomplete_callback()
        return

    char = " " if key == "Space" else key
    if digit_only_target is not None and target == digit_only_target and not char.isdigit():
        return

    try:
        target.insert(tk.INSERT, char)
    except tk.TclError:
        target.insert(tk.END, char)

    if autocomplete_callback and target == autocomplete_target:
        autocomplete_callback()
