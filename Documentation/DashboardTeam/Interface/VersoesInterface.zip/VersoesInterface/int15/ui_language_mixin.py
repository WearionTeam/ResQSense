import tkinter as tk

from language_config import LANGUAGE_OPTIONS, get_language_label, translate


class LanguageUIMixin:
    def t(self, key, **kwargs):
        return translate(self.current_language, key, **kwargs)

    def get_language_name(self, code=None):
        selected = code if code else self.current_language
        return get_language_label(selected)

    def set_language(self, language_code):
        valid_codes = {code for _, code in LANGUAGE_OPTIONS}
        if language_code not in valid_codes:
            return

        self.current_language = language_code

        if self.menu_open:
            self.menu_frame.place_forget()
            self.menu_open = False

        self.apply_translations_to_visible_widgets()
        self.refresh_sidebar_list_safe()
        self.draw_radar_safe()

    def apply_translations_to_visible_widgets(self):
        if self.login_station_label and self.login_station_label.winfo_exists():
            self.login_station_label.config(text=self.t("fire_station"))
        if self.login_name_label and self.login_name_label.winfo_exists():
            self.login_name_label.config(text=self.t("name_id"))
        if self.login_ops_label and self.login_ops_label.winfo_exists():
            self.login_ops_label.config(text=self.t("nr_operationals"))
        if self.login_button and self.login_button.winfo_exists():
            self.login_button.config(text=self.t("login"))

        if self.sidebar_title_label and self.sidebar_title_label.winfo_exists():
            self.sidebar_title_label.config(text=self.t("operational"))

        if self.menu_edit_button and self.menu_edit_button.winfo_exists():
            self.menu_edit_button.config(text=self.t("menu_edit"))
        if self.menu_resources_button and self.menu_resources_button.winfo_exists():
            self.menu_resources_button.config(text=self.t("menu_resources"))
        if self.menu_language_button and self.menu_language_button.winfo_exists():
            self.menu_language_button.config(text=self.t("menu_language"))

        if self.session_name_label and self.session_name_label.winfo_exists():
            self.session_name_label.config(text=self.t("session_name", name=self.team_leader_name))
        if self.end_session_button and self.end_session_button.winfo_exists():
            self.end_session_button.config(text=self.t("end_session"))

    def refresh_sidebar_list_safe(self):
        if not self.dashboard_active:
            return
        if not hasattr(self, "firefighter_list_frame"):
            return
        if not self.firefighter_list_frame or not self.firefighter_list_frame.winfo_exists():
            return
        self.refresh_sidebar_list()

    def draw_radar_safe(self):
        if not self.dashboard_active:
            return
        if not hasattr(self, "canvas"):
            return
        if not self.canvas or not self.canvas.winfo_exists():
            return
        self.draw_radar()

    def open_language_window(self):
        if self.menu_open:
            self.menu_frame.place_forget()
            self.menu_open = False

        if self.language_window and self.language_window.winfo_exists():
            self.language_window.lift()
            return

        popup = tk.Toplevel(self.root)
        popup.title(self.t("language_title"))
        popup.geometry("330x430")
        popup.configure(bg=self.bg_color)
        popup.resizable(False, False)
        popup.transient(self.root)
        popup.grab_set()
        self.language_window = popup

        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 165
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 215
        popup.geometry(f"+{x}+{y}")

        popup.protocol("WM_DELETE_WINDOW", self.close_language_window)

        container = tk.Frame(popup, bg=self.bg_color, relief="solid", bd=1, padx=14, pady=14)
        container.pack(fill=tk.BOTH, expand=True, padx=16, pady=16)

        tk.Label(container, text=self.t("language_select"), bg=self.bg_color, font=("Arial", 11, "bold"), anchor="w").pack(fill=tk.X, pady=(0, 8))
        tk.Label(
            container,
            text=self.t("language_current", language=self.get_language_name()),
            bg=self.bg_color,
            font=("Arial", 10),
            anchor="w",
        ).pack(fill=tk.X, pady=(0, 8))

        list_frame = tk.Frame(container, bg=self.bg_color)
        list_frame.pack(fill=tk.BOTH, expand=True)

        scroll = tk.Scrollbar(list_frame, orient=tk.VERTICAL)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        language_list = tk.Listbox(list_frame, yscrollcommand=scroll.set, exportselection=False, font=("Arial", 10))
        language_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.configure(command=language_list.yview)

        current_index = 0
        for idx, (label, code) in enumerate(LANGUAGE_OPTIONS):
            language_list.insert(tk.END, label)
            if code == self.current_language:
                current_index = idx
        language_list.selection_set(current_index)
        language_list.activate(current_index)
        language_list.see(current_index)

        def apply_selected_language(_event=None):
            selected = language_list.curselection()
            if not selected:
                return
            _, code = LANGUAGE_OPTIONS[selected[0]]
            self.set_language(code)
            self.close_language_window()

        language_list.bind("<Double-Button-1>", apply_selected_language)
        language_list.bind("<Return>", apply_selected_language)

        buttons = tk.Frame(container, bg=self.bg_color)
        buttons.pack(fill=tk.X, pady=(10, 0))

        tk.Button(
            buttons,
            text=self.t("language_apply"),
            relief="solid",
            bd=1,
            command=apply_selected_language,
        ).pack(side=tk.LEFT, padx=(0, 8), ipadx=10)

        tk.Button(
            buttons,
            text=self.t("language_cancel"),
            relief="solid",
            bd=1,
            command=self.close_language_window,
        ).pack(side=tk.LEFT, ipadx=10)

    def close_language_window(self):
        if self.language_window and self.language_window.winfo_exists():
            try:
                self.language_window.grab_release()
            except tk.TclError:
                pass
            self.language_window.destroy()
        self.language_window = None
