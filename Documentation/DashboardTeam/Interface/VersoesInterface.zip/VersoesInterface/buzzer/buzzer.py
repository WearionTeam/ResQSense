from gpiozero import Buzzer
from time import sleep

# Define o pino GPIO 17
bz = Buzzer(17)

print("Bipando...")

try:
    while True:
        bz.on()   # Liga o som
        sleep(0.5)
        bz.off()  # Desliga o som
        sleep(0.5)
except KeyboardInterrupt:
    print("\nEncerrado pelo usuário")