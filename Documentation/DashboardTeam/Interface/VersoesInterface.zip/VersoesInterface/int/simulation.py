import random

class HardwareSimulator:
    
    @staticmethod
    def get_fake_data():
        #1. Decide whether a critical event occurs (10% probability)
        happens_critical = random.random() < 0.10 

        bpm = 0
        spo2 = 0
        temp = 0.0

        if happens_critical:
            # If it is critical, we choose a random problem to simulate
            problem_type = random.choice(['hr_high', 'spo2_low', 'temp_high'])
            
            if problem_type == 'hr_high':
                bpm = random.randint(110, 160)       # Dangerous heartbeat
                spo2 = random.randint(95, 100)      # Normal SpO2
                temp = round(random.uniform(36.5, 37.5), 1)
            
            elif problem_type == 'spo2_low':
                bpm = random.randint(60, 100)        # normal bpm
                spo2 = random.randint(80, 94)        # Shortness of breath (<95)
                temp = round(random.uniform(36.5, 37.5), 1)
                
            else: # temp_high
                bpm = random.randint(90, 120)        # Fever raises the bpms slightly
                spo2 = random.randint(95, 100)
                temp = round(random.uniform(41.0, 43.0), 1) # High fever
        
        else:
             # --- NORMAL STATE (90% of the time) ---
            # Healthy values 
            bpm = random.randint(60, 90)
            spo2 = random.randint(97, 100)
            temp = round(random.uniform(36.2, 37.2), 1)

        # GPS always varies a little bit
        return {
            'hr': bpm,
            'spo2': spo2,
            'temp': temp,
            'lat': 40.644 + random.uniform(-0.0001, 0.0001), 
            'long': -8.645 + random.uniform(-0.0001, 0.0001)
        }
    


    