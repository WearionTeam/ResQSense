import random

class HardwareSimulator:
    """
    Simula o comportamento do hardware (Colete + LoRa).
    """
    @staticmethod
    def get_fake_data():
        # 1. Decide se acontece um evento crítico (Probabilidade de 10%)
        # Se quiseres mais frequente, muda 0.10 para 0.30. Se quiseres menos, põe 0.05.
        happens_critical = random.random() < 0.10 

        bpm = 0
        spo2 = 0
        temp = 0.0

        if happens_critical:
            # Se for crítico, escolhemos um problema aleatório para simular
            problem_type = random.choice(['hr_high', 'spo2_low', 'temp_high'])
            
            if problem_type == 'hr_high':
                bpm = random.randint(110, 160)       # Batimento perigoso
                spo2 = random.randint(95, 100)      # SpO2 normal
                temp = round(random.uniform(36.5, 37.5), 1)
            
            elif problem_type == 'spo2_low':
                bpm = random.randint(60, 100)        # HR normal
                spo2 = random.randint(80, 94)       # Falta de ar (<95)
                temp = round(random.uniform(36.5, 37.5), 1)
                
            else: # temp_high
                bpm = random.randint(90, 120)        # Febre sobe um pouco o HR
                spo2 = random.randint(95, 100)
                temp = round(random.uniform(41.0, 43.0), 1) # Febre alta
        
        else:
            # --- ESTADO NORMAL (90% das vezes) ---
            # Valores saudáveis 
            bpm = random.randint(60, 90)
            spo2 = random.randint(97, 100)
            temp = round(random.uniform(36.2, 37.2), 1)

        # GPS varia sempre um bocadinho 
        return {
            'hr': bpm,
            'spo2': spo2,
            'temp': temp,
            'lat': 40.644 + random.uniform(-0.0001, 0.0001), 
            'long': -8.645 + random.uniform(-0.0001, 0.0001)
        }