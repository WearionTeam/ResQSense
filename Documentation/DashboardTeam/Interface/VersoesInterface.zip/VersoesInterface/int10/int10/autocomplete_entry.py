import re
import tkinter as tk
from tkinter import ttk
import unicodedata


class AutocompleteEntry(tk.Frame):
    """
    Entry with autocomplete suggestions that stay visible while typing.
    """

    def __init__(self, master, options, width=37, max_rows=8, **kwargs):
        super().__init__(master, **kwargs)
        self.options = sorted(set(options))
        self.filtered_options = []
        self.max_rows = max_rows
        self.var = tk.StringVar()

        row = tk.Frame(self, bg=self.cget("bg"))
        row.pack(fill=tk.BOTH, expand=True)

        self.entry = ttk.Entry(row, textvariable=self.var, width=width)
        self.entry.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.entry.bind("<KeyRelease>", self._on_key_release)
        self.entry.bind("<Down>", self._focus_listbox)
        self.entry.bind("<Return>", self._select_first_from_popup)
        self.entry.bind("<Escape>", self._hide_popup)
        self.entry.bind("<FocusOut>", self._on_focus_out)

        self.arrow_btn = ttk.Button(row, text="v", width=2, command=self._toggle_popup)
        self.arrow_btn.pack(side=tk.RIGHT, padx=(4, 0))
        self.arrow_btn.bind("<FocusOut>", self._on_focus_out)

        self.popup = None
        self.listbox = None

    def set_options(self, options):
        self.options = sorted(set(options))
        if self.popup and self.popup.winfo_exists():
            self._populate_listbox(self.options)

    def _on_key_release(self, event):
        if event.keysym in ("Up", "Down", "Return", "Tab", "Escape"):
            return

        typed = self.var.get().strip()
        if not typed:
            self._hide_popup()
            return

        self.filtered_options = [opt for opt in self.options if self._matches_prefix(opt, typed)]
        if self.filtered_options:
            self._show_popup(self.filtered_options)
        else:
            self._hide_popup()

    def _toggle_popup(self):
        if self.popup and self.popup.winfo_exists():
            self._hide_popup()
            return
        self._show_popup(self.options)
        self.entry.focus_set()

    def _show_popup(self, items):
        if not items:
            self._hide_popup()
            return

        if self.popup and self.popup.winfo_exists():
            self._populate_listbox(items)
            self._position_popup()
            return

        self.popup = tk.Toplevel(self)
        self.popup.overrideredirect(True)
        self.popup.transient(self.winfo_toplevel())
        self.popup.configure(bg="#000000", bd=1)

        container = tk.Frame(self.popup, bg="white", bd=0)
        container.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)

        scrollbar = ttk.Scrollbar(container, orient=tk.VERTICAL)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.listbox = tk.Listbox(
            container,
            height=min(self.max_rows, len(items)),
            exportselection=False,
            activestyle="none",
        )
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.listbox.configure(yscrollcommand=scrollbar.set)
        scrollbar.configure(command=self.listbox.yview)

        self.listbox.bind("<ButtonRelease-1>", self._select_from_listbox)
        self.listbox.bind("<Button-1>", self._select_from_listbox)
        self.listbox.bind("<Double-Button-1>", self._select_from_listbox)
        self.listbox.bind("<Return>", self._select_from_listbox)
        self.listbox.bind("<Escape>", self._hide_popup)
        self.listbox.bind("<FocusOut>", self._on_focus_out)

        self._populate_listbox(items)
        self._position_popup()
        self.popup.deiconify()
        self.popup.lift()
        self.entry.focus_set()
        self.entry.icursor(tk.END)

    def _position_popup(self):
        if not (self.popup and self.popup.winfo_exists()):
            return
        self.update_idletasks()
        x = self.entry.winfo_rootx()
        y = self.entry.winfo_rooty() + self.entry.winfo_height()
        width = max(120, self.entry.winfo_width())
        self.popup.update_idletasks()
        height = self.popup.winfo_reqheight()
        self.popup.geometry(f"{width}x{height}+{x}+{y}")

    def _populate_listbox(self, items):
        if not self.listbox:
            return
        self.listbox.delete(0, tk.END)
        for item in items:
            self.listbox.insert(tk.END, item)
        self.listbox.configure(height=min(self.max_rows, max(1, len(items))))
        if items:
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(0)

    def _focus_listbox(self, _event=None):
        if self.popup and self.popup.winfo_exists() and self.listbox and self.listbox.size() > 0:
            self.listbox.focus_set()
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(0)
            return "break"
        if self.options:
            self._show_popup(self.options)
        return "break"

    def _select_first_from_popup(self, _event=None):
        if self.popup and self.popup.winfo_exists() and self.listbox and self.listbox.size() > 0:
            self.var.set(self.listbox.get(0))
            self._hide_popup()
            self.after_idle(lambda: self.event_generate("<<AutocompleteSelected>>"))
            return "break"
        return None

    def _select_from_listbox(self, event=None):
        if not self.listbox:
            return
        index = None
        if event is not None and hasattr(event, "y"):
            try:
                index = int(self.listbox.nearest(event.y))
            except (tk.TclError, ValueError):
                index = None
        if index is None:
            cur = self.listbox.curselection()
            if cur:
                index = cur[0]
        if index is None or index < 0 or index >= self.listbox.size():
            return
        self.var.set(self.listbox.get(index))
        self._hide_popup()
        self.after_idle(lambda: self.event_generate("<<AutocompleteSelected>>"))
        return "break"

    def _on_focus_out(self, _event=None):
        self.after(160, self._hide_if_focus_outside)

    def _hide_if_focus_outside(self):
        focus = self.focus_get()
        if focus in (self.entry, self.arrow_btn, self.listbox):
            return
        if focus and str(focus).startswith(str(self)):
            return
        if self.popup and self.popup.winfo_exists() and focus and str(focus).startswith(str(self.popup)):
            return
        if self.popup and self.popup.winfo_exists():
            px, py = self.winfo_pointerxy()
            hovered = self.popup.winfo_containing(px, py)
            if hovered and str(hovered).startswith(str(self.popup)):
                return
        self._hide_popup()

    def _hide_popup(self, _event=None):
        if self.popup and self.popup.winfo_exists():
            self.popup.destroy()
        self.popup = None
        self.listbox = None

    def hide_suggestions(self):
        self._hide_popup()

    def focus_input(self):
        self.entry.focus_set()
        self.entry.icursor(tk.END)

    def _normalize(self, value):
        normalized = unicodedata.normalize("NFKD", value)
        return "".join(ch for ch in normalized if not unicodedata.combining(ch)).lower()

    def _matches_prefix(self, option, typed):
        norm_option = self._normalize(option)
        norm_typed = self._normalize(typed)
        if norm_option.startswith(norm_typed):
            return True
        words = [word for word in re.split(r"[^a-z0-9]+", norm_option) if word]
        return any(word.startswith(norm_typed) for word in words)

    def get(self):
        return self.var.get().strip()

    def set(self, value):
        self.var.set(value)
