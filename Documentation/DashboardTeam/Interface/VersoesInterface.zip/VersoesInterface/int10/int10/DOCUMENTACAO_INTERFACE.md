# Documentacao da Interface - ResQSense

## 1. Objetivo
Este documento descreve a interface grafica da aplicacao **ResQSense**, desenvolvida em `Tkinter`, para monitorizacao de operacionais em contexto de missao.

O foco e explicar:
- organizacao visual da interface;
- fluxo de utilizacao;
- regras funcionais visiveis no UI;
- integracao entre interface, modelo de dados e simulacao.

## 2. Tecnologias e Estrutura
### Stack principal
- `Python` (aplicacao desktop)
- `Tkinter` (`tk`, `ttk`, `messagebox`) para interface grafica
- `gpiozero` (opcional) para buzzer fisico

### Modulos do projeto
- `testedashboard.py`: interface principal (login, dashboard, alertas, menu, idioma)
- `models.py`: entidades de dominio (`Operator`, `Session`, `DashboardController`)
- `simulation.py`: gerador de dados simulados de sensores
- `autocomplete_entry.py`: campo de texto com autocomplete para selecao de corporacao
- `firestation_database.py`: base de dados local simulada de corporacoes

## 3. Fluxo de Utilizacao
### 3.1 Login
O utilizador inicia a missao atraves de tres campos:
- `Fire Station` (autocomplete);
- `Name/ID` do chefe de equipa;
- `Nr of Operationals` (valor inteiro).

Regras:
- corporacao obrigatoria;
- nome do chefe obrigatorio;
- numero de operacionais entre `1` e `12`;
- valor por omissao: `5`.

Apos validacao:
- inicia-se nova sessao (`DashboardController.start_new_session()`);
- abre o dashboard;
- o chefe de equipa e adicionado automaticamente com ID visual `C`.

### 3.2 Dashboard
O dashboard e composto por:
- **Header**: menu, identidade da app, relogio e avatar da sessao;
- **Sidebar**: lista de operacionais com estado e detalhes;
- **Area central**: radar tatico com posicionamento relativo;
- **Rodape do radar**: historico de warnings (ultimos registos visiveis).

### 3.3 Gestao da sessao
- botao `+` adiciona operacional por popup;
- modo edicao permite remover operacionais (exceto lider);
- painel de sessao permite terminar sessao e regressar ao login.

## 4. Componentes de Interface
### 4.1 Header
- icone de menu (`menu`) abre acoes rapidas;
- relogio atualizado em tempo real;
- clique no avatar abre painel de sessao.

### 4.2 Menu lateral superior
Opcoes:
- `Edit` (ativa/desativa modo de remocao);
- `Additional Resources` (abre painel de sessao);
- `Language` (abre seletor de idioma).

### 4.3 Sidebar de operacionais
Cada cartao mostra:
- avatar + ID;
- nome;
- estado visual;
- detalhe biometrico e localizacao (quando selecionado).

Estados visuais:
- `leader`: lider da equipa;
- `normal`: operacional sem alerta;
- `critical`: cartao vermelho;
- `no_signal`: cartao preto.

### 4.4 Radar
Elementos:
- cruz de orientacao e circulos concentricos;
- lider no centro (`C`);
- operacionais distribuidos por angulo/distancia;
- agrupamento automatico quando ha sobreposicao (`1/2`, etc.);
- escala de `0 m` a `40 m`.

### 4.5 Historico de warnings
- painel inferior da area de radar;
- lista timestamp + nome + motivo;
- mostra ate 4 entradas visiveis;
- historico em memoria limitado a 50 registos.

### 4.6 Popup critico ("Man Down")
Quando surge condicao critica:
- abre popup modal em primeiro plano;
- apresenta operacional afetado e motivo;
- botao `View More` foca diretamente o operacional na sidebar/radar;
- fila de popups evita duplicacoes imediatas.

## 5. Regras Funcionais Relevantes
### 5.1 Atualizacao periodica
- ciclo de simulacao executado a cada `2000 ms`.

### 5.2 Criterios de alerta biometrico
No modelo (`Operator.check_health_status()`):
- `HR HIGH`: frequencia cardiaca `> 105`;
- `SpO2 LOW`: oxigenacao `< 95` (com valor valido);
- `TEMP HIGH`: temperatura `> 37.8`.

### 5.3 Perda de sinal
Durante cada ciclo:
- pode ocorrer estado `POOR CONNECTION`;
- esse estado e tratado como critico visualmente (`no_signal`) e entra no historico.

### 5.4 Limite de operacionais
- o total de operacionais adicionados respeita o valor definido no login (`max_operationals`);
- IDs dos operacionais sao gerados automaticamente de forma sequencial (`1`, `2`, `3`, ...).

## 6. Internacionalizacao (i18n)
O sistema inclui seletor de idioma com varias opcoes na UI.

Atualmente existem traducoes completas no dicionario para:
- `pt`, `en`, `es`, `fr`, `de`, `it`.

Para idiomas sem chave de traducao, o sistema aplica fallback para ingles.

## 7. Estrutura de Dados na Interface
A lista `self.firefighters` guarda dicionarios com o estado em tempo real:
- `id`: identificador visual (`C` para lider);
- `name`: nome exibido;
- `angle` e `dist`: posicao relativa no radar;
- `logic_ref`: referencia ao objeto `Operator`;
- `is_leader`: identifica lider;
- `status`: `leader`, `normal`, `critical`, `no_signal`;
- `active_warnings`: alertas ativos do ciclo;
- `signal_lost`: flag interna de continuidade de sinal.

## 8. Dependencias e Execucao
Pre-requisitos:
- Python 3 com `tkinter` disponivel.

Dependencia opcional:
- `gpiozero` (somente se houver hardware buzzer).

Execucao:
```bash
cd int10
python testedashboard.py
```

## 9. Limitacoes Atuais e Melhorias Sugeridas
- A base de dados de corporacoes e estatica (in-memory).
- Ainda nao ha persistencia de sessao/alertas em ficheiro ou cloud.
- Nao ha autenticacao de utilizadores.
- A simulacao usa dados aleatorios; integracao com sensores reais pode substituir `HardwareSimulator`.

Melhorias recomendadas:
- exportacao de relatorio de sessao;
- persistencia de historico de alertas;
- testes automatizados para validacoes de UI e regras de alerta;
- separacao adicional entre camada de apresentacao e regras de negocio.
